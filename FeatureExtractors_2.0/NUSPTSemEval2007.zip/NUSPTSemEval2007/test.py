__author__ = 'Mohammad'

import NUSPTSemEval2007FeatureExtractor;

NUSPTSemEval2007FeatureExtractor.__argumentparser__("c-1,-1.c+1,+1.c-2,-2.c+2,+2.c-2,-1.c-1,+1.c+1,+2.c-3,-1.c-2,+1.c-1,+2.c+1,+3_p-3,+3_all")