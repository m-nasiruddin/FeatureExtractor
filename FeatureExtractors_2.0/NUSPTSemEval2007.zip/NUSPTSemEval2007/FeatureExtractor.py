# -*- coding: utf-8 -*-
__author__ = 'Mohammad'
import re
import string

import InfoSemCor


class Loc:
    def __init__(self, sentence, word):
        self.sentence = sentence
        self.word = word


def __argumentparser__(features):
    mincolval = list()
    maxcolval = list()
    minposval = 0
    maxposval = 0
    singlewords = False
    ftrvalues = features.split("_")
    for ftrvalue in ftrvalues:
        if "c" in ftrvalue:
            colvals = ftrvalue.split(".")
            for colval in colvals:
                colposs = colval.split("c")
                cols = colposs[1].split(",")
                mincolval.append(int(cols[0]))
                maxcolval.append(int(cols[1]))
        elif "p" in ftrvalue:
            posposs = ftrvalue.split("p")
            poss = posposs[1].split(",")
            for pos in poss:
                if "-" in pos:
                    minposval = int(poss[0])
                    pos = pos.replace("-", "")
                    minposabsval = int(pos)
                else:
                    pos = pos.replace("+", "")
                    maxposval = int(pos)
        elif "all" in ftrvalue:
            singlewords = True
    return [singlewords, mincolval, maxcolval, minposval, maxposval]


def __senses__(loc, txt):
    lexsn = txt[loc.sentence][loc.word].lexsn
    outstr = ''
    if lexsn is not None and len(lexsn) > 0:
        outstr += '"' + lexsn + '"\t'
    return outstr


def __localcollocation__(loc, text, mincolval, maxcolval):
    slist = text[loc.sentence]
    lexsn = text[loc.sentence][loc.word].lexsn
    outstr = ''
    if lexsn is not None and len(lexsn) > 0:
        for i in range(0, len(mincolval)):
            outstr += '"'
            for cw in range(loc.word + mincolval[i], loc.word + maxcolval[i] + 1):
                if cw != loc.word:
                    if cw >= 0 and cw < len(slist):
                        if slist[cw].is_punc():
                            outstr += slist[cw].word
                        else:
                            if slist[cw].lemma is not "":
                                outstr += slist[cw].lemma.lower()
                            else:
                                outstr += slist[cw].word.lower()
                    else:
                        outstr += '∅'
                    if (cw < loc.word + maxcolval[i]):
                        outstr += "_"
            outstr += '"\t'
    return outstr


def __postags__(loc, text, minposval, maxposval):
    slist = text[loc.sentence]
    lexsn = text[loc.sentence][loc.word].lexsn
    outstr = ''
    if lexsn is not None and len(lexsn) > 0:
        for i in range(loc.word + minposval, loc.word + maxposval + 1):
            if i >= 0 and i < len(slist):
                if slist[i].is_punc():
                    outstr += '"' + "ε" + '"\t'
                else:
                    outstr += '"' + slist[i].pos + '"\t'
            else:
                outstr += '"ε"\t'
    return outstr


def __surroundingwords__(loc, winindex, wi, text):
    slist = text[loc.sentence]
    lexsn = text[loc.sentence][loc.word].lexsn
    outstr = ''
    if lexsn is not None and len(lexsn) > 0:
        curwindex = winindex.get(wi)
        for i in range(loc.word + curwindex[0] - 1, loc.word + curwindex[1]+1):
            if i >= 0 and i < len(slist):
                if slist[i].lemma is not "":
                    outstr += '"' + slist[i].lemma.lower() + '"\t'
                else:
                    outstr += '"' + slist[i].word.lower() + '"\t'
            else:
                outstr += '"0"\t'
        if len(slist) > 1:
            outstr += "\n"
    return outstr


def __surroundingwordswithoutstopwords__(locs, stoplist, feature_list, window_file):
    regex_is_number = re.compile(r'^\-?[0-9]+\.?[0-9]*')
    lnnumber = 0
    contexts = list()
    target_indices = list()
    min_window = 0
    max_window = 0

    for ln in range(0, len(feature_list)):
        line = feature_list[ln]
        lnnumber += 1
        current_features = line.split('"\t"')
        # Removing heading and training quote characters
        current_features[0] = current_features[0][1:len(current_features[0])]
        current_features[len(current_features) - 1] = \
            current_features[len(current_features) - 1][0:len(current_features[len(current_features) - 1]) - 1]
        features_without_stopwords = list()
        i = 0
        trgwindex = locs[ln]
        while i != len(current_features):
            if ((current_features[i].lower() not in stoplist) or (current_features[i].lower() in stoplist and i!=trgwindex)) and \
                            regex_is_number.match(current_features[i]) is None and \
                            current_features[i].lower()[0] not in string.punctuation:
                features_without_stopwords.append(current_features[i])
            else:
                if i <= trgwindex:
                    trgwindex -= 1
            i += 1
        if (trgwindex -1 > min_window):
            min_window = trgwindex - 1
        if len(features_without_stopwords) - trgwindex > max_window:
            max_window = len(features_without_stopwords) - trgwindex
        target_indices.append(min(len(features_without_stopwords)-1,max(0,trgwindex)))
        contexts.append(features_without_stopwords)
    outlist = list()
    window_file.write("\t"+str(min_window)+"\t"+str(max_window)+"\n");
    for j in range(0, len(contexts)):
        c = contexts[j]
        output_string = ""
        for i in range(target_indices[j] - min_window+1, target_indices[j] + max_window):
            if i >= 0 and i < len(c):
                if i!=target_indices[j]:
                    output_string += '\"' + c[i] + '\"\t'
            else:
                output_string += '\"0\"\t'
        output_string += '\n'
        outlist.append(output_string)
    return outlist


def __load_stopwords__(filename):
    stoplist = list()
    stopwords = open(filename, "r")
    stopwordsstring = stopwords.read()
    for stopword in stopwordsstring.split("\n"):
        stoplist.append(stopword)
    return stoplist


def extract_features(semcor, dstdirectory, featurenames):
    argmnts = __argumentparser__(featurenames)
    mincolval = argmnts[1]
    maxcolval = argmnts[2]
    minposval = argmnts[3]
    maxposval = argmnts[4]

    values = semcor.split("</s>")
    cmd = ""
    rdf = ""
    lemma = ""
    pos = ""
    wnsn = ""
    lexsn = ""
    pn = ""
    ot = ""
    text = []
    windex = dict()
    winindex = dict()
    sentcnt = 0
    stoplist = __load_stopwords__("data/stopwords.txt");

    for s in values:
        s = s.strip()
        sentence = []
        if s.find("<s snum") > 0:
            lines = s.split('\n')
            wcnt = 0
            for line in lines:
                if line.startswith('<wf'):
                    line_split = line.replace('>', ' ').split()
                    for item in line_split:
                        if item.startswith("cmd"):
                            cmd = item[4:]
                        elif item.startswith("rdf"):
                            rdf = item[4:]
                        elif item.startswith("lemma"):
                            lemma = item[6:]
                        elif item.startswith("pos"):
                            pos = item[4:]
                        elif item.startswith("wnsn"):
                            wnsn = item[5:]
                        elif item.startswith("lexsn"):
                            lexsn = item[6:]
                        elif item.startswith("pn"):
                            pn = item[3:]
                        elif item.startswith("ot"):
                            ot = item[3:]
                        elif item.startswith("dc"):
                            None
                        elif item.startswith("sep"):
                            None
                        elif not item.startswith("<wf"):

                            word = item[:item.index("<")]
                            info = InfoSemCor.InfoSemcor(cmd, rdf, pos, lemma, wnsn, lexsn, pn, ot, word)
                            sentence.append(info)
                            wval = windex.get(lemma)
                            if wval is None:
                                wval = list()
                                windex[lemma] = wval
                            wval.append(Loc(sentcnt, wcnt))
                            cmd = ""
                            rdf = ""
                            pos = ""
                            lemma = ""
                            wnsn = ""
                            lexsn = ""
                            pn = ""
                            ot = ""
                            wcnt += 1
                elif line.startswith('<punc'):
                    line_split = line.replace('>', ' ').split()
                    for item in line_split:
                        if not item.startswith("<punc"):
                            word = item[:item.index("<")]
                            info = InfoSemCor.InfoSemcor("", "", "", "", "", "", "", "", word)
                            sentence.append(info)
                            wcnt += 1
        sentcnt += 1
        text.append(sentence)

        for w in windex.keys():
            slist = windex.get(w)
            wmin = 0
            wmax = 0
            for loc in slist:
                slen = len(text[loc.sentence])
                lwmin = -(loc.word - 1)
                lwmax = slen - loc.word
                if (lwmin < wmin):
                    wmin = lwmin
                if (lwmax > wmax):
                    wmax = lwmax
            winindex[w] = [wmin, wmax]

    window_file = open("data/indexes/windows.csv","w")
    for wi in windex.keys():
        if len(wi) > 0:
            outfile = open(dstdirectory + "/" + wi + ".csv", "w")
            outfile.write('"SENSE"')
            curnum = 1

            senselist = list()
            loccollist = list()
            postaglist = list()
            swordlist = list()
            locs = list()
            for loc in windex.get(wi):
                senselist.append(__senses__(loc, text))
                loccollist.append(__localcollocation__(loc, text, mincolval, maxcolval))
                postaglist.append(__postags__(loc, text, minposval, maxposval))
                swordlist.append(__surroundingwords__(loc, winindex, wi, text))
                locs.append(loc.word)
            window_file.write(wi)
            newswordlist = __surroundingwordswithoutstopwords__(locs, stoplist, swordlist,window_file)
            window_file.flush()

            ncols = -1
            for i in range(0, len(senselist)):
                outstr = senselist[i]
                outstr += loccollist[i]
                outstr += postaglist[i]
                outstr += newswordlist[i]
                if ncols == -1:
                    ncols = len(outstr.split("\t")) - 1
                    for i in range(1, ncols):
                        outfile.write('\t"A' + str(curnum) + '"')
                        curnum += 1
                    outfile.write('\n')
                outfile.write(outstr)
                outfile.flush()
            outfile.close()
    window_file.close()
    print("Successfully finished!")